---
title: Speaker 3
subtitle: Short description
layout: default
modal-id: 3
img: golden.png
thumbnail: golden-thumbnail.png
alt: image-alt
project-date:
client:
category:
description: Bio
---
