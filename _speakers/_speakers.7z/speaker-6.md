---
title: Speaker 6
subtitle: Short description
layout: default
modal-id: 6
img: roundicons.png
thumbnail: roundicons-thumbnail.png
alt: image-alt
project-date:
client:
category:
description: Bio
---
